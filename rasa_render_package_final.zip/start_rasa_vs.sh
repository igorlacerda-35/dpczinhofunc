#!/bin/bash
rasa run actions &
rasa shell
